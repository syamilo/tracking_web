<?php
$host = 'localhost';
$user = 'root';
$pswd = '';
$dbname = 'ssaa';

$conn = new mysqli($host, $user, $pswd, $dbname);
if (session_status() == PHP_SESSION_NONE) {
}
