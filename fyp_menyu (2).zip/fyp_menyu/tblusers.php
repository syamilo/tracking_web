<?php
include('db_connection.php');//read command from the connection.php

//sql to create table
$sql="CREATE TABLE users(
    user_id INT(6) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    pass VARCHAR(20) NOT NULL,
    email VARCHAR(200) NOT NULL)";

    if($conn->query($sql)===TRUE){
        echo"Table sysadmin created succesfully";
    }else{
        "Error creating table:".$conn->error;
    }
    $conn->close();
    ?>