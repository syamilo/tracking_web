<?php
include('db_connection.php'); // Include the database connection file

// SQL to create table
$sql = "CREATE TABLE child (
    child_id INT(6) NOT NULL AUTO_INCREMENT,
    user_id INT(6),
    fullName VARCHAR(50) NOT NULL,
    age VARCHAR(20) NOT NULL,
    addresses VARCHAR(200) NOT NULL,
    PRIMARY KEY (child_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
)";

// Execute SQL query
if($conn->query($sql) === TRUE) {
    echo "Table 'child' created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Close the database connection
$conn->close();
?>