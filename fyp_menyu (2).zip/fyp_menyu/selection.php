<?php
// Include the database connection file
include_once 'db_connection.php';

// Start the session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to index.php if user is not logged in
    header("Location: index.php");
    exit();
}

// Fetch logged-in user's details from the database
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$userDetails = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selection - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="selection.css">
</head>
<body>
<div class="banner">
        <div class="navbar">
            <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
            <ul>
                <li><a href="childrendetails.php">Add Child</a></li>
                <li><a href="passchange.php?user_id=' . $row_child['child_id'] . '" class="btn">Change Password</a></li>
                <li><a href="index.php"><button class="action_btn signup_btn" id="logoutBtn2" >Log Out</button></a></li>
            </ul>
        </div>
    </div>
    <div class="container">
        <table>
            <tr>
                <th>Child Name</th>
                <th>Age</th>
                <th>Teacher's Number</th>
                <th>School Address</th>
                <th>Home Address</th>
                <th colspan="3">Action</th>
            </tr>
            <?php
            // Fetch child details from the database and display in a table
            $query_child = "SELECT * FROM child WHERE user_id = ?";
            $stmt_child = $conn->prepare($query_child);
            $stmt_child->bind_param("i", $user_id);
            $stmt_child->execute();
            $result_child = $stmt_child->get_result();

            while ($row_child = $result_child->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row_child['fullName'] . '</td>';
                echo '<td>' . $row_child['age'] . '</td>';
                echo '<td>' . $row_child['phoneNumber'] . '</td>';
                echo '<td>' . $row_child['address'] . '</td>';
                echo '<td>' . $row_child['Home'] . '</td>';
                // Button to select this child and redirect to button.php
                echo '<td><a href="button.php?child_id=' . $row_child['child_id'] . '" class="btn">View</a></td>';
                echo '<td><a href="Delete.php?child_id=' . $row_child['child_id'] . '" class="btn">Delete</a></td>';
                echo '<td><a href="edit.php?child_id=' . $row_child['child_id'] . '" class="btn">Edit</a></td>';
                echo '</tr>';
            }

            $stmt_child->close();
            ?>
        </table>
    </div>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

