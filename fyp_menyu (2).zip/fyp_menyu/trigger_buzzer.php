<?php

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the request body
    $requestData = json_decode(file_get_contents('php://input'), true);

    // Check if the button is pressed
    if (isset($requestData['button']) && $requestData['button'] === 'pressed') {
        // Send a request to the NodeMCU to trigger the buzzer and LED
        $nodeMCUUrl = "http://<NodeMCU_IP>/trigger.php"; // Replace <NodeMCU_IP> with the IP address of your NodeMCU
        $ch = curl_init($nodeMCUUrl);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "trigger=buzzer");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        // Check if the request to NodeMCU was successful
        if ($response === 'success') {
            echo "Button Pressed";
        } else {
            http_response_code(500);
            echo "Failed to trigger buzzer on NodeMCU";
        }
    } else {
        http_response_code(400);
        echo "Invalid request data";
    }
} else {
    // If the request method is not POST, return an error
    http_response_code(405);
    echo "Method Not Allowed";
}

?>
