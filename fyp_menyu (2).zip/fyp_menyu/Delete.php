<?php
include('db_connection.php');

$id = $_GET['child_id'];

?>
<script>
    var confirmDelete = confirm('Are you sure you want to delete this info? ');

    if(confirmDelete){
        // If the user confirms deletion, execute the deletion query
        <?php
            $sqldel = "DELETE FROM child WHERE child_id='$id'";
            $resultdel = $conn->query($sqldel);
        ?>
        window.location.href='selection.php';
    }
    else{
        // If the user cancels deletion, do nothing
        // You might consider showing a message to the user here
    }
</script>