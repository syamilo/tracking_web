<?php
include_once 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize inputs
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $email = $_POST['email'];

    // Perform database query to check if the email exists
    $query = "SELECT COUNT(*) FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();

    if ($count > 0) {
        // Email already exists, display error message
        echo "<script>alert('Email address already in use. Please enter a different email.');</script>";
    } else {
        // Close the statement
        $stmt->close();
        
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and execute the INSERT query
        $sql = "INSERT INTO users (username, pass, email) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $hashedPassword, $email);
        
        if ($stmt->execute()) {
            echo "<script>alert('Signup successfully!.');
            window.location='index.php'
            </script>";
            //header("Location: index.php");
            exit();
        } else {
            echo "Error inserting user data into the database.";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="signup.css">
    <script>
        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            if (password !== confirmPassword) {
                alert("Password and confirm password must be the same.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
<header>
    <div class="container">
        <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
    </div>
</header><br><br><br><br><br><br>
<section class="signup">
    <div class="container">
    <a href="index.php"><img src='images/Back.png'  title='Back' width='30px' height='30px'></a>
        <h2>Sign Up</h2>
        <form id="signup-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return validateForm()">
            <table>
                <tr>
                    <td><label for="username">Name:</label></td>
                    <td><input type="text" name="username" id="username" placeholder="Username" required></td>
                </tr>
                <tr>
                    <td><label for="password">Password:</label></td>
                    <td><input type="password" name="password" id="password" placeholder="Password" required></td>
                </tr>
                <tr>
                    <td><label for="confirmPassword">Confirm Password:</label></td>
                    <td><input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" required></td>
                </tr>
                <tr>
                    <td><label for="email">Email:</label></td>
                    <td><input type="email" name="email" id="email" placeholder="Email" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button type="submit" class="btn">Sign Up</button></td>
                </tr>
            </table>
        </form>
    </div>
</section><br><br><br><br><br>
<footer>
    <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
</footer>
</body>
</html>
