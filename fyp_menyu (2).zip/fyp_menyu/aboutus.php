<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="index.css">
    <style>
        /* Additional CSS for photo sizes */
        .team .member img {
            max-width: 100px; /* Limit the maximum width of the photos */
            height: auto; /* Maintain aspect ratio */
        }
        .back-btn-container {
            position: absolute;
            left: 20px; /* Adjust the left position as needed */
            top: 20px; /* Adjust the top position as needed */
        }

        .back-btn {
            background-color: #007bff; /* Blue background color */
            color: white; /* White text color */
            padding: 10px 20px; /* Add padding as needed */
            text-decoration: none; /* Remove underline */
            border-radius: 5px; /* Add border radius */
            display: inline-block; /* Make it inline block */
        }

        .back-btn:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
        .divider {
            border-top: 1px solid #ccc;
            margin: 20px 0;
        }

        /* Arrange team information horizontally */
        .team {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap; /* Allow wrapping to the next line */
        }

        /* Style individual team member */
        .team-member {
            flex-basis: 30%; /* Adjust width as needed */
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 10px;
        }
    </style>
</head>
<body>
<header>
        <div class="back-btn-container">
            <a href="index.php" class="back-btn">Back</a>
        </div>
        <div class="container">
            <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
        </div>
    </header>
    <section class="about">
        <div class="container">
            <h2>About Us</h2>
            <p>
                SchoolSafe Arrival Assist is a revolutionary project aimed at enhancing the safety and security of students during pick-up hours at schools. Our system utilizes cutting-edge technology to streamline the process of student pick-up, ensuring that every child is accounted for and safely handed over to their authorized guardians.
            </p>
            <p>
                With our innovative solution, parents and guardians can have peace of mind knowing that their children are in safe hands. By leveraging advanced IoT devices and real-time monitoring, we provide schools and parents with a reliable platform to track student arrivals and departures, effectively reducing wait times and minimizing the risk of unauthorized access.
            </p>
            <p>
                At SchoolSafe Arrival Assist, we are committed to creating a safer and more efficient environment for students, parents, and schools alike. Join us in our mission to revolutionize student pick-up processes and ensure the well-being of future generations.
            </p>
            <div class="divider"></div>
            <div class="team">
                <div class="member">
                    <img src="Images/me.jpg" alt="Team Member">
                    <h3>Muhammad Iskandar </h3>
                    <p>Website Developer</p>
                </div>
                <div class="member">
                    <img src="Images/afiz.jpg" alt="Team Member">
                    <h3>Muhammad Hafiz </h3>
                    <p>IoT Devices Engineer</p>
                </div>
                <div class="member">
                    <img src="Images/ajiq.jpg" alt="Team Member">
                    <h3>Shaikh Haziq Hariri </h3>
                    <p>Product Designer</p>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
