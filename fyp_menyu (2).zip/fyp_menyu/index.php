<?php
// Include the database connection file
include_once 'db_connection.php';

// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data and sanitize inputs
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];

    // Validate form inputs (ensure username and password are not empty)
    if (!empty($username) && !empty($password)) {
        // Prepare and execute the SQL query to retrieve user information
        $select_sql = "SELECT user_id, username, pass FROM users WHERE username = ?";
        $stmt = $conn->prepare($select_sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a matching user is found
        if ($result->num_rows == 1) {
            // Fetch user data
            $row = $result->fetch_assoc();
            $stored_password = $row['pass'];
            // Verify password
            if (password_verify($password, $stored_password)) {
                // Password is correct, store user_id in session
                $_SESSION['user_id'] = $row['user_id'];
                // Redirect to selection.php after successful login
                header("Location: selection.php");
                exit();
            } else {
                // Password is incorrect, set error message
                $error = "Invalid username or password. Please try again.";
            }
        } else {
            // No matching user found, set error message
            $error = "Invalid username or password. Please try again.";
        }
    } else {
        // Username or password is empty, set error message
        $error = "Username and password are required.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
            
        </div>
    </header>
    <section class="hero">
        <div class="container">
            <h2>Welcome to SchoolSafe Arrival Assist</h2><br>
            <p>Ensuring the safety and security of students during pickup hours.</p>
        </div>
    </section>
    <section class="login">
        <div class="container">
        <center><img src='images/REA0084.JPG' width='60px' height='60px'></center>
            <h2>Login</h2>
            <?php if(isset($error)) { ?>
                <div class="error"><?php echo $error; ?></div><br>
            <?php } ?>
            <form method="post">
                    <label>Username:</label>
                    <input type="text" name="username" placeholder="Username" required><br><br>
                    <label>Password:</label>
                    <input type="password" name="password" placeholder="Password" required><br><br>
                    <button type="submit" class="login-btn">Login</button>
                    <a href="signup.php" class="signout-btn">Signup</a>
            </form>
        </div>
    </section>
    
    <a href="aboutus.php" class="aboutus-btn">About Us</a>
    <br><br>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
        </div>
    </footer>

    <script>
        var socket = new WebSocket('ws://192.168.70.96:81');

        socket.onmessage = function(event) {
            console.log(event.data);
        };
    </script>
</body>
</html>
