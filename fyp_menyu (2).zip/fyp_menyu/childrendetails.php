<?php
include_once 'db_connection.php';

$errors = []; // Initialize the errors array

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = htmlspecialchars($_POST['fullName']);
    $age = htmlspecialchars($_POST['age']);
    $phoneNumber = htmlspecialchars($_POST['phoneNumber']);
    $address = htmlspecialchars($_POST['address']);
    $homeAddress = htmlspecialchars($_POST['homeAddress']);

echo"!empty($fullName) && !empty($age) && !empty($phoneNumber) && !empty($address) && !empty($homeAddress)";

// Check if all fields are filled
if (!empty($fullName) && !empty($age) && !empty($phoneNumber) && !empty($address) && !empty($homeAddress)) {
    // Get user_id from session
    session_start();
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        // Prepare and bind the SQL statement to insert data into child table
        $insert_query = "INSERT INTO child (user_id, fullName, age, phoneNumber, Home ,address ) VALUES (?, ?, ?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("isisss", $user_id, $fullName, $age, $phoneNumber,$homeAddress, $address );


        // Execute insertion statement
        if ($insert_stmt->execute()) {
            // Redirect after successful submission
            header("Location: selection.php");
            exit();
        } else {
            // Handle insertion error
            $errors[] = "Error: " . $insert_stmt->error;
        }
    } else {
        // Redirect to login page if user is not logged in
        header("Location: login.php");
        exit();
    }
} else {
    // Handle case when all fields are not filled
    $errors[] = "All fields are required. Please fill out all fields.";
}
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Children Details - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="child.css">
</head>
<body>
    <div class="container">
        <div class="children-details">
        <a href="selection.php"><img src='images/Back.png'  title='Back' width='30px' height='30px'></a>
            <h2>Children Details Form</h2>
            <?php if (!empty($errors)) : ?>
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <table>
                    <tr>
                        <td><label for="fullName">Full Name:</label></td>
                        <td><input type="text" id="fullName" name="fullName" placeholder="Full Name" required></td>
                    </tr>
                    <tr>
                        <td><label for="age">Age:</label></td>
                        <td><input type="text" id="age" name="age" placeholder="Age" required></td>
                    </tr>
                    <tr>
                        <td><label for="phoneNumber">Teacher's Number:</label></td>
                        <td><input type="text" id="phoneNumber" name="phoneNumber" placeholder="Phone Number" required></td>
                    </tr>
                    <tr>
                        <td><label for="address">School Address:</label></td>
                        <td><input type="text" id="address" name="address" placeholder="Address" required></td>
                    </tr>
                    <tr>
                        <td><label for="homeAddress">Home Address:</label></td>
                        <td><input type="text" id="homeAddress" name="homeAddress" placeholder="Home Address" required></td>
                    </tr>

                    <!-- Add other input fields as needed -->
                </table>
                <button type="submit" class="btn">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>
