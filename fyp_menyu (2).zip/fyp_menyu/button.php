<?php
// Include the database connection file
include_once 'db_connection.php';

// Start the session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit();
}

// Check if child ID is provided in the URL
if (isset($_GET['child_id'])) {
    $child_id = $_GET['child_id'];

    // Fetch child details from the database based on the provided child ID
    $query_child = "SELECT * FROM child WHERE user_id = ? AND child_id = ?";
    $stmt_child = $conn->prepare($query_child);
    $stmt_child->bind_param("ii", $_SESSION['user_id'], $child_id);
    $stmt_child->execute();
    $result_child = $stmt_child->get_result();

    if ($result_child->num_rows > 0) {
        $childDetails = $result_child->fetch_assoc();

        // Fetch device ID associated with the child ID
        $query_device = "SELECT device_id FROM device WHERE child_id = ?";
        $stmt_device = $conn->prepare($query_device);
        $stmt_device->bind_param("i", $child_id);
        $stmt_device->execute();
        $result_device = $stmt_device->get_result();

        if ($result_device->num_rows > 0) {
            $device_row = $result_device->fetch_assoc();
            $device_id = $device_row['device_id'];

            // Fetch timestamp data for the specified device ID from button_press_logs
            $query_timestamp = "SELECT timestamp FROM button_press_logs WHERE device_id = ?";
            $stmt_timestamp = $conn->prepare($query_timestamp);
            $stmt_timestamp->bind_param("s", $device_id);
            $stmt_timestamp->execute();
            $result_timestamp = $stmt_timestamp->get_result();

            // Store timestamps in an array for display
            $timestamps = array();
            while ($row = $result_timestamp->fetch_assoc()) {
                $timestamps[] = $row['timestamp'];
            }

            $stmt_timestamp->close();
        } else {
            // Handle case where device ID is not found for the child
            $device_id = "Device ID not found";
        }

        $stmt_device->close();
    } else {
        // Child not found, handle this case accordingly (redirect or show a message)
        // For example:
        header("Location: selection.php");
        exit();
    }

    $stmt_child->close();
} else {
    // Child ID is not provided in the URL, handle this case accordingly (redirect or show a message)
    // For example:
    header("Location: selection.php");
    exit();
}


// Fetch logged-in user's details from the database
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$userDetails = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Button - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Style the menu button */
        .dropbtn {
            background-color: #007bff; /* Blue background color */
            color: white;
            padding: 12px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        /* Hover effect for the menu button */
        .dropbtn:hover, .dropbtn:focus {
            background-color: #0056b3; /* Darker blue on hover */
        }

        /* Dropdown menu content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 5px;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Style other buttons in the dropdown */
        .dropdown-content .btn {
            background-color: #fff; /* White background color */
            color: black;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            display: block;
            width: 100%;
            text-align: left;
        }

        .dropdown-content .btn:hover {
            background-color: #f1f1f1; /* Slightly darker background on hover */
        }

        /* Ensure footer sticks to the bottom */
        html, body {
            height: 100%;
        }
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(240, 222, 222, 0.75),rgba(255, 252, 252, 0.75)),url(Images/545050_314827191942653_913217171_n.jpg);
            background-size: cover;
            background-position: center;
            background-attachment: fixed; /* Add this line */
        }

        /* Style the search form */
#searchForm {
    margin-bottom: 20px;
}

/* Style the search input */
.cari {
    width: 400px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 5px;
}

/* Style the search button */
.search {
    background-color: #007bff;
    color: white;
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-decoration: none;
}

/* Hover effect for the search button */
.search:hover {
    background-color: #0056b3;
}
        
        .container table {
            width: 100%;
            border-collapse: collapse;
        }

        .container td {
            padding: 8px;
            border: 1px solid #ddd;
        }

        .container td:first-child {
            font-weight: bold;
        }

        footer {
            margin-top: auto;
            padding: 10px 20px; /* Add padding for spacing */
            box-sizing: border-box; /* Include padding in height calculation */
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 5px;
            border-bottom: 1px solid #ccc;
            padding-bottom: 5px;
        }

        #signalButton {
            margin-top: 20px;
            background-color: #28a745; /* Green background color */
            color: white;
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        #signalButton:hover {
            background-color: #218838; /* Darker green on hover */
        }

        .time {
            margin: 20px auto; /* Center the timestamps section horizontally */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            width: 40%;
        }

/* Remaining styles */
.time h3 {
    margin-bottom: 10px;
}

.time ul {
    list-style-type: none;
    padding: 0;
}

.time li {
    margin-bottom: 5px;
}

.time p {
    margin-top: 10px;
}


        footer{
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
           
            bottom: 0;
            width: 100%;
        }

    </style>
</head>
<body>
<header>
        <div class="container">
            </div>
        <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
        </div>
    </header>
    <section class="button">
    <div class="container">
    <div>
        <?php if (!empty($childDetails)) : ?>
            <h3>Child Details:</h3>
            <table>
                <tr>
                    <td>Child Id:</td>
                    <td><?php echo $childDetails['child_id']; ?></td>
                </tr>
                <tr>
                    <td>Child Name:</td>
                    <td><?php echo $childDetails['fullName']; ?></td>
                </tr>
                <tr>
                    <td>Age:</td>
                    <td><?php echo $childDetails['age']; ?></td>
                </tr>
                <tr>
                    <td>Teacher's Number:</td>
                    <td><?php echo $childDetails['phoneNumber']; ?></td>
                </tr>
                <tr>
                    <td>Shcool Address:</td>
                    <td><?php echo $childDetails['address']; ?></td>
                </tr>
                <tr>
                    <td>Home Address:</td>
                    <td><?php echo $childDetails['Home']; ?></td>
                </tr>
                <!-- Add other child details here -->
            </table>
        <?php else : ?>
            <p>No child details found.</p>
        <?php endif; ?>
    </div>
</div>

     <div class="time">
    <h3>Timestamps for button press from: <?php echo $childDetails['fullName']; ?></h3>
    <form id="searchForm">
        <label for="searchInput">Search Date:</label>
        <input type="Date" id="searchInput" name="searchInput"  class="cari" placeholder="Enter timestamp..."><br><br>
        <button type="button"  class="search" onclick="searchTimestamps()">Search</button>
    
    </form>
    <?php if (!empty($timestamps)) : ?>
        <ul>
            <?php
            // Get the number of timestamps
            $count = count($timestamps);
            // Get the start index for slicing
            $start_index = max(0, $count - 30); // Ensure start index is not negative
            // Slice the timestamps array to get the last 5 timestamps
            $recent_timestamps = array_slice($timestamps, $start_index);
            ?>
            <?php foreach ($recent_timestamps as $timestamp) : ?>
                <li><?php echo $timestamp; ?></li>
            <?php endforeach; ?>
        </ul>
    <?php else : ?>
        <p>No timestamps found for this device.</p>
    <?php endif; ?>
                <!-- Button to send signal -->
                <button id="signalButton" class="btn" onclick="toggle()">Send Signal</button>
</div>

        </div>
        <div class="dropdown">
                <nav>
                <a href="selection.php" class="btn">Back</a><br><br>    
            </nav>
    </section>
    <footer>
            <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
    </footer>

    <script>
        var socket = new WebSocket('ws://192.168.70.96:81');

        socket.onmessage = function(event) {
            console.log(event.data);
            const data = event.data.split(":");

            const msg       = data [0] || "";
            const sensor    = data [1] || "";

            if (sensor == "led") {
                var button = document.getElementById("signalButton");
                button.innerHTML = msg == "1" ? "Signal Sent" : "Send Signal";
                button.style.backgroundColor = msg == "1" ? "#dc3545" : "#28a745";
            } else if (sensor == "reset") {
                resetButtonState();
                // Trigger page refresh when reset signal is received
                location.reload();
            }
        };

        function toggle() {
            var button = document.getElementById("signalButton");
            var status = button.innerHTML === "Send Signal" ? "1" : "0";
            var device_id = "<?php echo $device_id; ?>"; // Include the device_id from PHP
            
            // Send messages with device_id included
            socket.send(status + ":led:" + device_id + ":localhost");
            socket.send(status + ":buzzer:" + device_id + ":localhost");
        }


        function resetButtonState() {
            var button = document.getElementById("signalButton");
            button.innerHTML = "Send Signal";
            button.style.backgroundColor = "#28a745";
        }
    </script>
   <script>
    // Function to be called when the page loads
    window.onload = function() {
        resetTimestampsDisplay(); // Reset display for all timestamps
        searchTimestamps(); // Call the function to display all timestamps
    };

    function resetTimestampsDisplay() {
        // Get all timestamp elements
        var timestamps = document.querySelectorAll(".time ul li");

        // Reset display for all timestamps
        for (var i = 0; i < timestamps.length; i++) {
            timestamps[i].style.display = "block";
        }
    }

    function searchTimestamps() {
        // Get the search input value
        var searchInput = document.getElementById("searchInput").value.toLowerCase();

        // Get all timestamp elements
        var timestamps = document.querySelectorAll(".time ul li");

        // Reset display for all timestamps
        resetTimestampsDisplay();

        var found = false; // Flag to check if any timestamp is found

        // Loop through each timestamp element again
        for (var i = 0; i < timestamps.length; i++) {
            var timestampText = timestamps[i].textContent.toLowerCase();

            // Check if the timestamp contains the search input
            if (!timestampText.includes(searchInput)) {
                timestamps[i].style.display = "none"; // Hide the timestamp if not matched
            } else {
                found = true; // Set the flag to true if any timestamp is found
            }
        }

        // If no timestamp is found, display a message
        if (!found) {
            document.getElementById("noDataFound").style.display = "block";
        } else {
            document.getElementById("noDataFound").style.display = "none"; // Hide the message if timestamps are found
        }
    }
</script>


    </body>
</html>
