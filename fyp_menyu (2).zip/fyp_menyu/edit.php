<?php
include_once 'db_connection.php';

$errors = []; // Initialize the errors array

// Check if the child ID is provided in the URL
if(isset($_GET['child_id'])) {
    $child_id = $_GET['child_id'];

    // Retrieve child details based on child ID
    $select_query = "SELECT * FROM child WHERE child_id = ?";
    $select_stmt = $conn->prepare($select_query);
    $select_stmt->bind_param("i", $child_id);
    $select_stmt->execute();
    $result = $select_stmt->get_result();

    if($result->num_rows == 1) {
        $child = $result->fetch_assoc();
        $fullName = $child['fullName'];
        $age = $child['age'];
        $phoneNumber = $child['phoneNumber'];
        $address = $child['address'];
        $homeAddress = $child['Home'];
    } else {
        // Child not found, redirect or handle error
        header("Location: selection.php");
        exit();
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $fullName = htmlspecialchars($_POST['fullName']);
    $age = htmlspecialchars($_POST['age']);
    $phoneNumber = htmlspecialchars($_POST['phoneNumber']);
    $address = htmlspecialchars($_POST['address']);
    $homeAddress = htmlspecialchars($_POST['homeAddress']);

    // Check if all fields are filled
    if (!empty($fullName) && !empty($age) && !empty($phoneNumber) && !empty($address) && !empty($homeAddress)) {
        // Update child details in the database
        $update_query = "UPDATE child SET fullName = ?, age = ?, phoneNumber = ?, Home = ?, address = ? WHERE child_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("sisssi", $fullName, $age, $phoneNumber, $homeAddress, $address, $child_id);

        if($update_stmt->execute()) {
            // Redirect after successful update
            header("Location: selection.php");
            exit();
        } else {
            // Handle update error
            $errors[] = "Error updating child details: " . $update_stmt->error;
        }
    } else {
        // Handle case when all fields are not filled
        $errors[] = "All fields are required. Please fill out all fields.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Child Details - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="child.css">
</head>
<body>
    <div class="container">
        <div class="children-details">
            <a href="selection.php"><img src='images/Back.png'  title='Back' width='30px' height='30px'></a>
            <h2>Edit Child Details</h2>
            <?php if (!empty($errors)) : ?>
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            <?php endif; ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . '?child_id=' . $child_id); ?>">
                <table>
                    <tr>
                        <td><label for="fullName">Full Name:</label></td>
                        <td><input type="text" id="fullName" name="fullName" placeholder="Full Name" value="<?php echo $fullName; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="age">Age:</label></td>
                        <td><input type="text" id="age" name="age" placeholder="Age" value="<?php echo $age; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="phoneNumber">Teacher's Number:</label></td>
                        <td><input type="text" id="phoneNumber" name="phoneNumber" placeholder="Phone Number" value="<?php echo $phoneNumber; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="address">School Address:</label></td>
                        <td><input type="text" id="address" name="address" placeholder="Address" value="<?php echo $address; ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="homeAddress">Home Address:</label></td>
                        <td><input type="text" id="homeAddress" name="homeAddress" placeholder="Home Address" value="<?php echo $homeAddress; ?>" required></td>
                    </tr>
                </table>
                <button type="submit" class="btn">Save Changes</button>
            </form>
        </div>
    </div>
</body>
</html>
