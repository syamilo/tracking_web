<?php

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the request body
    $requestData = json_decode(file_get_contents('php://input'), true);

    // Check if the trigger request is received
    if (isset($requestData['trigger']) && $requestData['trigger'] === 'buzzer') {
        // Perform any action you want when the buzzer trigger request is received
        // For example, you can activate the buzzer and LED here
        // In this example, we simply return a success message
        echo "success";
    } else {
        http_response_code(400);
        echo "Invalid request data";
    }
} else {
    // If the request method is not POST, return an error
    http_response_code(405);
    echo "Method Not Allowed";
}

?>
