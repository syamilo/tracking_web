<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if not logged in
    header("Location: index.php");
    exit();
}

// Include the database connection file
include_once 'db_connection.php';

// Initialize variables
$error = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $oldPassword = $_POST['oldPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmNewPassword = $_POST['confirmNewPassword'];

    // Retrieve user's ID from session
    $userId = $_SESSION['user_id'];

    // Validate form inputs
    if (!empty($oldPassword) && !empty($newPassword) && !empty($confirmNewPassword)) {
        // Prepare and execute the SQL query to retrieve user's password
        $select_sql = "SELECT pass FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($select_sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Fetch user's stored password
        $row = $result->fetch_assoc();
        $storedPassword = $row['pass'];

        // Verify old password
        if (password_verify($oldPassword, $storedPassword)) {
            // Verify new password and confirm new password match
            if ($newPassword === $confirmNewPassword) {
                // Hash the new password
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                
                // Update the password in the database
                $update_sql = "UPDATE users SET pass = ? WHERE user_id = ?";
                $stmt = $conn->prepare($update_sql);
                $stmt->bind_param("si", $hashedPassword, $userId);
                if ($stmt->execute()) {
                    $success = "Password updated successfully.";
                } else {
                    $error = "Error updating password.";
                }
            } else {
                $error = "New password and confirm new password do not match.";
            }
        } else {
            $error = "Old password is incorrect.";
        }
    } else {
        $error = "All fields are required.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
<header>
    <div class="container">
        <h1>SCHOOLSAFE ARRIVAL ASSIST</h1>
    </div>
</header>
<br><br><br><br><br><br>
<section class="signup">
    <div class="container">
        <a href="selection.php"><img src='images/Back.png'  title='Back' width='30px' height='30px'></a>
        <h2>Change Password</h2>
        <?php if(isset($error)) { ?>
            <div class="error"><?php echo $error; ?></div>
        <?php } ?>
        <?php if(isset($success)) { ?>
            <div class="success"><?php echo $success; ?></div>
        <?php } ?>
        <form method="post">
            <table>
                <tr>
                    <td><label for="oldPassword">Old Password:</label></td>
                    <td><input type="password" name="oldPassword" id="oldPassword" placeholder="Old Password" required></td>
                </tr>
                <tr>
                    <td><label for="newPassword">New Password:</label></td>
                    <td><input type="password" name="newPassword" id="newPassword" placeholder="New Password" required></td>
                </tr>
                <tr>
                    <td><label for="confirmNewPassword">Confirm New Password:</label></td>
                    <td><input type="password" name="confirmNewPassword" id="confirmNewPassword" placeholder="Confirm New Password" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button type="submit" class="btn">Change Password</button></td>
                </tr>
            </table>
        </form>
    </div>
</section>
<br><br><br><br><br>
<footer>
    <p>&copy; <?php echo date("Y"); ?> SchoolSafe Arrival Assist. All rights reserved.</p>
</footer>
</body>
</html>
