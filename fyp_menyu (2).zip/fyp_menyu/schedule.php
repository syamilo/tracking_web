<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <style>
        body {
        font-family: Arial, sans-serif;
        background-image: linear-gradient(rgba(240, 222, 222, 0.75),rgba(255, 252, 252, 0.75)),url(Images/545050_314827191942653_913217171_n.jpg);
        background-size: cover;
        background-position: center;
        background-attachment: fixed; /* Add this line */
    }
    </style>
    <header>
        <div class="container">
            <h1>SCHEDULE</h1>
            <nav>
                <a href="button.php" class="btn">Back</a>
            </nav>
        </div>
    </header>
    <section class="schedule">
        <div class="container">
            <!-- Place to display the schedule -->
            <div class="schedule-content">
                <!-- Insert your schedule content here -->
                <!-- For example, you can add an image of the schedule -->
                <img src="Images/schedule_image.jpg" alt="Schedule">
            </div>
        </div>
    </section>
</body>
</html>
