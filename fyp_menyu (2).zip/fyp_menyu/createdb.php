<?php
$servername = "localhost"; //domain name or ip address
$username = "root";
$password = "";

//Create command for connection to server
//option 1
$con=new mysqli($servername,$username,$password);// Create connection with mysql

//option 2
//con=new msqli("localhost","root",""); //create connection with mysql

//Check connection
if($con->connect_error){
    die("Connection failed:" .$con->connect_error);
}

//create database
$createdb = "CREATE DATABASE ssaa"; //letak nama database --> command sql
if($con->query($createdb)===TRUE){ //execute command to create a db --> query()
    echo "Database created successfully";
}
else{
    echo "Error creating database:".$con->error;
}

$con->close(); //close connection with mysql
?>