<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Button Press Logs - SCHOOLSAFE ARRIVAL ASSIST</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Add your custom styles here */
        body {
            font-family: Arial, sans-serif;
            background-image: linear-gradient(rgba(240, 222, 222, 0.75),rgba(255, 252, 252, 0.75)),url(Images/545050_314827191942653_913217171_n.jpg);
            background-size: cover;
            background-position: center;
            background-attachment: fixed; /* Add this line */
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f2f2f2;
        }
        .btn-back {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Button Press Logs</h1>
        </div>
    </header>
    <div class="container">
        <?php
        // Include the database connection file
        require 'conn.php';

        // Retrieve button press logs from the database
        $query = "SELECT * FROM button_press_logs ORDER BY timestamp DESC";
        $result = $conn->query($query);

        // Check if there are any logs
        if ($result->num_rows > 0) {
            // Output logs in a table
            echo '<table>';
            echo '<tr><th>Timestamp</th></tr>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr><td>' . $row['timestamp'] . '</td></tr>';
            }
            echo '</table>';
        } else {
            // No logs found message
            echo '<p>No button press logs available</p>';
        }

        // Close the database connection
        $conn->close();
        ?>
        <!-- Button to go back to button.php -->
        <a href="button.php" class="btn-back">Back</a>
    </div>
</body>
</html>
