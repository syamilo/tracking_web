<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the button is pressed and device_id is provided
    if (isset($_POST['button_pressed']) && $_POST['button_pressed'] === 'true' && isset($_POST['device_id'])) {
        // Get the device_id from the POST data
        $device_id = $_POST['device_id'];

        // Database connection
        require 'conn.php';

        // Insert data into the database
        $insertQuery = "INSERT INTO button_press_logs (device_id, timestamp) VALUES (?, NOW())"; // Assuming button_press_logs table has 'device_id' and 'timestamp' columns
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("s", $device_id);
        
        if ($stmt->execute()) {
            echo "Button press logged successfully for device ID: " . $device_id . ". Saya sudah sampai.";
        } else {
            echo "Error: " . $insertQuery . "<br>" . $conn->error;
        }

        // Close the statement and the database connection
        $stmt->close();
        $conn->close();
    } else {
        echo "Invalid request data. Button not pressed or device ID missing.";
    }
} else {
    echo "Invalid request method.";
}
?>
